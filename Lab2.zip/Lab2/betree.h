void add(int v);
int find(int v);
void printBST()	;
void unlink();